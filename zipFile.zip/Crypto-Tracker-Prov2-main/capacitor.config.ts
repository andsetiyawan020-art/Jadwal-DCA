import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.gentz.btctracker',
  appName: 'BTC & ETH Tracker',
  webDir: 'dist'
};

export default config;
