import { Router, type IRouter } from "express";
import healthRouter from "./health";
import priceRouter from "./price";

const router: IRouter = Router();

router.use(healthRouter);
router.use(priceRouter);

export default router;
