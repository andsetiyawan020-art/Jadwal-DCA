import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.andisetiyawan.btcethtracker',
  appName: 'BTC ETH Tracker',
  webDir: 'dist'
};

export default config;
