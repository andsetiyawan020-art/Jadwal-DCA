import { useState, useEffect, useCallback, useRef } from "react";
import {
  AreaChart, Area, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid,
} from "recharts";

interface IndodaxPrice {
  last: number;
  buy: number;
  sell: number;
  high: number;
  low: number;
}

interface PriceState {
  btc: IndodaxPrice | null;
  eth: IndodaxPrice | null;
  loading: boolean;
  error: string | null;
  lastUpdated: Date | null;
}

const REFRESH_INTERVAL = 30_000;

async function fetchIndodaxTicker(pair: string): Promise<IndodaxPrice> {
  const res = await fetch(`/api/price/${pair}`, { cache: "no-store" });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  const t = data.ticker;
  return {
    last: parseFloat(t.last),
    buy: parseFloat(t.buy),
    sell: parseFloat(t.sell),
    high: parseFloat(t.high),
    low: parseFloat(t.low),
  };
}

function useIndodaxPrices() {
  const [state, setState] = useState<PriceState>({
    btc: null, eth: null, loading: true, error: null, lastUpdated: null,
  });
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const fetchPrices = useCallback(async () => {
    setState(prev => ({ ...prev, loading: true, error: null }));
    try {
      const [btc, eth] = await Promise.all([
        fetchIndodaxTicker("btcidr"),
        fetchIndodaxTicker("ethidr"),
      ]);
      setState({ btc, eth, loading: false, error: null, lastUpdated: new Date() });
    } catch (e) {
      setState(prev => ({
        ...prev,
        loading: false,
        error: e instanceof Error ? e.message : "Gagal mengambil harga",
      }));
    }
  }, []);

  useEffect(() => {
    fetchPrices();
    timerRef.current = setInterval(fetchPrices, REFRESH_INTERVAL);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [fetchPrices]);

  return { ...state, refetch: fetchPrices };
}

type Coin = "BTC" | "ETH";

interface Transaction {
  id: string;
  date: string;
  coin: Coin;
  jumlahBeli: number;
  fee: number;
  hargaBeliPerCoin: number;
}

const STORAGE_KEY = "btceth_transactions";

function formatRp(n: number) {
  return `Rp ${Math.round(n).toLocaleString("id-ID")}`;
}

function formatNum(n: number) {
  return Math.round(n).toLocaleString("id-ID");
}

function formatCoin(n: number, coin: Coin) {
  if (coin === "BTC") return n.toFixed(8) + " BTC";
  return n.toFixed(6) + " ETH";
}

function generateId() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

type TabType = "BTC" | "ETH" | "Dashboard";

const tabs: TabType[] = ["BTC", "ETH", "Dashboard"];

const BTC_COLOR = "#F7931A";
const ETH_COLOR = "#627EEA";
const ACCENT = "#64FFDA";

function BitcoinIcon({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
      <circle cx="16" cy="16" r="16" fill={BTC_COLOR} fillOpacity="0.15" />
      <path d="M22 13.5c.3-2-1.2-3-3.3-3.7l.7-2.7-1.6-.4-.6 2.6c-.4-.1-.9-.2-1.4-.3l.6-2.6-1.6-.4-.7 2.7c-.4-.1-.7-.2-1-.2l-2.1-.5-.4 1.7s1.2.3 1.2.3c.7.2.8.7.8 1l-2 7.8c-.1.3-.4.7-1 .5 0 0-1.2-.3-1.2-.3l-.8 1.8 2 .5c.4.1.7.2 1 .3l-.7 2.7 1.6.4.7-2.7c.4.1.9.2 1.4.3l-.7 2.7 1.6.4.7-2.7c2.8.5 4.9.3 5.8-2.2.7-2-.1-3.2-1.5-3.9 1.1-.3 1.9-1 2.1-2.4zm-3.8 5.3c-.5 2-3.9 1-5 .7l.9-3.5c1.1.3 4.6.8 4.1 2.8zm.5-5.3c-.5 1.8-3.4.9-4.3.7l.8-3.2c.9.2 3.9.7 3.5 2.5z" fill={BTC_COLOR} />
    </svg>
  );
}

function EthereumIcon({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
      <circle cx="16" cy="16" r="16" fill={ETH_COLOR} fillOpacity="0.15" />
      <path d="M16 5l-6.5 11.5L16 19.5l6.5-3L16 5z" fill={ETH_COLOR} />
      <path d="M9.5 16.5L16 27l6.5-10.5L16 19.5l-6.5-3z" fill={ETH_COLOR} fillOpacity="0.7" />
    </svg>
  );
}

function CodeIcon({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={ACCENT} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="16 18 22 12 16 6" />
      <polyline points="8 6 2 12 8 18" />
    </svg>
  );
}

function TrashIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="3 6 5 6 21 6" />
      <path d="M19 6l-1 14H6L5 6" />
      <path d="M10 11v6M14 11v6" />
      <path d="M9 6V4h6v2" />
    </svg>
  );
}

function PlusIcon({ size = 18 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}

function TrendUpIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
      <polyline points="17 6 23 6 23 12" />
    </svg>
  );
}

function TrendDownIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="23 18 13.5 8.5 8.5 13.5 1 6" />
      <polyline points="17 18 23 18 23 12" />
    </svg>
  );
}

interface FormState {
  date: string;
  coin: Coin;
  jumlahBeli: string;
  fee: string;
  hargaBeliPerCoin: string;
}

const today = () => new Date().toISOString().split("T")[0];

function TransactionForm({
  onAdd,
  defaultCoin,
}: {
  onAdd: (tx: Transaction) => void;
  defaultCoin?: Coin;
}) {
  const [form, setForm] = useState<FormState>({
    date: today(),
    coin: defaultCoin ?? "BTC",
    jumlahBeli: "",
    fee: "",
    hargaBeliPerCoin: "",
  });
  const [open, setOpen] = useState(false);

  const modalBersih =
    form.jumlahBeli && form.fee
      ? Math.max(0, parseFloat(form.jumlahBeli) - parseFloat(form.fee))
      : null;
  const koinDiterima =
    modalBersih && form.hargaBeliPerCoin && parseFloat(form.hargaBeliPerCoin) > 0
      ? modalBersih / parseFloat(form.hargaBeliPerCoin)
      : null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const jb = parseFloat(form.jumlahBeli);
    const fee = parseFloat(form.fee);
    const harga = parseFloat(form.hargaBeliPerCoin);
    if (!form.date || isNaN(jb) || isNaN(fee) || isNaN(harga) || harga <= 0) return;
    onAdd({
      id: generateId(),
      date: form.date,
      coin: form.coin,
      jumlahBeli: jb,
      fee: fee,
      hargaBeliPerCoin: harga,
    });
    setForm({ date: today(), coin: defaultCoin ?? "BTC", jumlahBeli: "", fee: "", hargaBeliPerCoin: "" });
    setOpen(false);
  };

  const coinColor = form.coin === "BTC" ? BTC_COLOR : ETH_COLOR;

  return (
    <div style={{ marginBottom: "1.5rem" }}>
      {!open ? (
        <button
          onClick={() => setOpen(true)}
          style={{
            display: "flex",
            alignItems: "center",
            gap: "0.5rem",
            padding: "0.75rem 1.25rem",
            background: "var(--accent-dim)",
            border: "1px solid var(--border-strong)",
            borderRadius: "10px",
            color: "var(--accent)",
            fontFamily: "'Space Grotesk', sans-serif",
            fontWeight: 600,
            fontSize: "0.9rem",
            cursor: "pointer",
            transition: "all 0.2s",
            width: "100%",
            justifyContent: "center",
          }}
          onMouseEnter={e => {
            (e.currentTarget as HTMLButtonElement).style.boxShadow = "var(--accent-glow)";
            (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--accent)";
          }}
          onMouseLeave={e => {
            (e.currentTarget as HTMLButtonElement).style.boxShadow = "none";
            (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--border-strong)";
          }}
        >
          <PlusIcon /> Tambah Transaksi
        </button>
      ) : (
        <div className="fade-in" style={{
          background: "var(--card)",
          border: "1px solid var(--border-strong)",
          borderRadius: "14px",
          padding: "1.5rem",
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1.25rem" }}>
            <h3 style={{ fontSize: "1rem", fontWeight: 600, color: "var(--accent)" }}>Transaksi Baru</h3>
            <button onClick={() => setOpen(false)} style={{
              background: "none", border: "none", color: "var(--text-muted)", cursor: "pointer", fontSize: "1.3rem", lineHeight: 1
            }}>×</button>
          </div>
          <form onSubmit={handleSubmit}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
              <div>
                <label style={labelStyle}>Tanggal</label>
                <input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                  style={inputStyle} required />
              </div>
              <div>
                <label style={labelStyle}>Coin</label>
                <select value={form.coin} onChange={e => setForm(f => ({ ...f, coin: e.target.value as Coin }))}
                  style={{ ...inputStyle, color: coinColor, fontWeight: 600 }}>
                  <option value="BTC">₿ Bitcoin (BTC)</option>
                  <option value="ETH">Ξ Ethereum (ETH)</option>
                </select>
              </div>
              <div>
                <label style={labelStyle}>Jumlah Beli (IDR)</label>
                <input type="number" placeholder="1000000" value={form.jumlahBeli}
                  onChange={e => setForm(f => ({ ...f, jumlahBeli: e.target.value }))}
                  style={inputStyle} required min="0" step="any" />
              </div>
              <div>
                <label style={labelStyle}>Fee (IDR)</label>
                <input type="number" placeholder="1500" value={form.fee}
                  onChange={e => setForm(f => ({ ...f, fee: e.target.value }))}
                  style={inputStyle} required min="0" step="any" />
              </div>
              <div style={{ gridColumn: "1 / -1" }}>
                <label style={labelStyle}>Harga Beli per Coin (IDR)</label>
                <input type="number" placeholder="450000000" value={form.hargaBeliPerCoin}
                  onChange={e => setForm(f => ({ ...f, hargaBeliPerCoin: e.target.value }))}
                  style={inputStyle} required min="0.01" step="any" />
              </div>
            </div>

            {(modalBersih !== null || koinDiterima !== null) && (
              <div className="fade-in" style={{
                marginTop: "1rem",
                padding: "0.75rem 1rem",
                background: "var(--bg-2)",
                borderRadius: "8px",
                border: "1px solid var(--border)",
                display: "flex",
                gap: "1.5rem",
                flexWrap: "wrap",
              }}>
                {modalBersih !== null && (
                  <div>
                    <div style={{ fontSize: "0.72rem", color: "var(--text-muted)", marginBottom: "2px" }}>Modal Bersih</div>
                    <div style={{ fontFamily: "'JetBrains Mono', monospace", color: "var(--accent)", fontSize: "0.88rem", fontWeight: 600 }}>
                      {formatRp(modalBersih)}
                    </div>
                  </div>
                )}
                {koinDiterima !== null && (
                  <div>
                    <div style={{ fontSize: "0.72rem", color: "var(--text-muted)", marginBottom: "2px" }}>Koin Diterima</div>
                    <div style={{ fontFamily: "'JetBrains Mono', monospace", color: coinColor, fontSize: "0.88rem", fontWeight: 600 }}>
                      {formatCoin(koinDiterima, form.coin)}
                    </div>
                  </div>
                )}
              </div>
            )}

            <div style={{ display: "flex", gap: "0.75rem", marginTop: "1.25rem" }}>
              <button type="submit" style={{
                flex: 1, padding: "0.75rem", background: "var(--accent)", color: "#0A192F",
                border: "none", borderRadius: "8px", fontFamily: "'Space Grotesk', sans-serif",
                fontWeight: 700, fontSize: "0.9rem", cursor: "pointer", transition: "opacity 0.2s",
              }}>
                Simpan Transaksi
              </button>
              <button type="button" onClick={() => setOpen(false)} style={{
                padding: "0.75rem 1.25rem", background: "transparent",
                border: "1px solid var(--border-strong)", borderRadius: "8px",
                color: "var(--text-muted)", fontFamily: "'Space Grotesk', sans-serif",
                cursor: "pointer",
              }}>
                Batal
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

const labelStyle: React.CSSProperties = {
  display: "block",
  fontSize: "0.78rem",
  fontWeight: 500,
  color: "var(--text-muted)",
  marginBottom: "0.35rem",
  letterSpacing: "0.03em",
  textTransform: "uppercase",
};

const inputStyle: React.CSSProperties = {
  width: "100%",
  padding: "0.65rem 0.85rem",
  background: "var(--input-bg)",
  border: "1px solid var(--border-strong)",
  borderRadius: "8px",
  color: "var(--text)",
  fontFamily: "'Space Grotesk', sans-serif",
  fontSize: "0.9rem",
  outline: "none",
  transition: "border-color 0.2s",
};

function TransactionTable({
  transactions,
  coin,
  onDelete,
}: {
  transactions: Transaction[];
  coin: Coin;
  onDelete: (id: string) => void;
}) {
  const filtered = transactions.filter(t => t.coin === coin).sort((a, b) => b.date.localeCompare(a.date));
  const coinColor = coin === "BTC" ? BTC_COLOR : ETH_COLOR;

  if (filtered.length === 0) {
    return (
      <div style={{
        textAlign: "center", padding: "3rem 1rem",
        color: "var(--text-muted)", fontSize: "0.9rem",
        background: "var(--card)", borderRadius: "14px",
        border: "1px dashed var(--border-strong)",
      }}>
        <div style={{ fontSize: "2rem", marginBottom: "0.5rem", opacity: 0.4 }}>
          {coin === "BTC" ? "₿" : "Ξ"}
        </div>
        Belum ada transaksi {coin}. Tambahkan transaksi pertama kamu!
      </div>
    );
  }

  return (
    <div style={{ overflowX: "auto" }}>
      <table style={{ width: "100%", borderCollapse: "separate", borderSpacing: "0 6px" }}>
        <thead>
          <tr>
            {["Tanggal", "Coin", "Jumlah Beli", "Fee", "Modal Bersih", "Koin Diterima", "Harga DCA", ""].map(h => (
              <th key={h} style={{
                padding: "0.5rem 0.85rem",
                textAlign: "left",
                fontSize: "0.72rem",
                fontWeight: 600,
                color: "var(--text-muted)",
                letterSpacing: "0.05em",
                textTransform: "uppercase",
                whiteSpace: "nowrap",
              }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {filtered.map(tx => {
            const modalBersih = tx.jumlahBeli - tx.fee;
            const koinDiterima = tx.hargaBeliPerCoin > 0 ? modalBersih / tx.hargaBeliPerCoin : 0;
            const hargaDca = koinDiterima > 0 ? modalBersih / koinDiterima : 0;
            return (
              <tr key={tx.id} className="fade-in" style={{ transition: "all 0.2s" }}>
                {[
                  <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.82rem" }}>{tx.date}</span>,
                  <span style={{ color: coinColor, fontWeight: 700, fontSize: "0.85rem" }}>
                    {coin === "BTC" ? "₿ BTC" : "Ξ ETH"}
                  </span>,
                  <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.85rem" }}>{formatRp(tx.jumlahBeli)}</span>,
                  <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.85rem", color: "#FF6B6B" }}>{formatRp(tx.fee)}</span>,
                  <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.85rem", color: "var(--accent)", fontWeight: 600 }}>{formatRp(modalBersih)}</span>,
                  <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.82rem", color: coinColor }}>{formatCoin(koinDiterima, coin)}</span>,
                  <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.82rem" }}>{formatRp(hargaDca)}</span>,
                ].map((cell, i) => (
                  <td key={i} style={{
                    padding: "0.75rem 0.85rem",
                    background: "var(--card)",
                    borderTop: "1px solid var(--border)",
                    borderBottom: "1px solid var(--border)",
                    whiteSpace: "nowrap",
                    ...(i === 0 ? { borderLeft: "1px solid var(--border)", borderTopLeftRadius: "10px", borderBottomLeftRadius: "10px" } : {}),
                    ...(i === 6 ? { borderRight: "1px solid var(--border)", borderTopRightRadius: "10px", borderBottomRightRadius: "10px" } : {}),
                  }}>
                    {cell}
                  </td>
                ))}
                <td style={{
                  padding: "0.75rem 0.5rem 0.75rem 0",
                  background: "var(--card)",
                  borderTop: "1px solid var(--border)",
                  borderBottom: "1px solid var(--border)",
                  borderRight: "1px solid var(--border)",
                  borderTopRightRadius: "10px",
                  borderBottomRightRadius: "10px",
                }}>
                  <button
                    onClick={() => {
                      if (confirm("Hapus transaksi ini?")) onDelete(tx.id);
                    }}
                    style={{
                      background: "none", border: "none", cursor: "pointer",
                      color: "var(--text-muted)", padding: "0.25rem 0.5rem",
                      borderRadius: "6px", transition: "all 0.15s",
                    }}
                    onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = "#FF6B6B"; (e.currentTarget as HTMLButtonElement).style.background = "rgba(255,107,107,0.1)"; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = "var(--text-muted)"; (e.currentTarget as HTMLButtonElement).style.background = "none"; }}
                    title="Hapus transaksi"
                  >
                    <TrashIcon />
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function CoinSummaryCard({ coin, transactions }: { coin: Coin; transactions: Transaction[] }) {
  const filtered = transactions.filter(t => t.coin === coin);
  const totalModal = filtered.reduce((s, t) => s + t.jumlahBeli, 0);
  const totalFee = filtered.reduce((s, t) => s + t.fee, 0);
  const totalModalBersih = totalModal - totalFee;
  const totalKoin = filtered.reduce((t, tx) => {
    const mb = tx.jumlahBeli - tx.fee;
    return t + (tx.hargaBeliPerCoin > 0 ? mb / tx.hargaBeliPerCoin : 0);
  }, 0);
  const dcaRata = totalKoin > 0 ? totalModalBersih / totalKoin : 0;
  const coinColor = coin === "BTC" ? BTC_COLOR : ETH_COLOR;
  const glowClass = coin === "BTC" ? "glow-btc" : "glow-eth";
  const textGlow = coin === "BTC" ? "text-glow-btc" : "text-glow-eth";

  return (
    <div style={{
      background: "var(--card)",
      border: `1px solid ${coin === "BTC" ? "rgba(247,147,26,0.25)" : "rgba(98,126,234,0.25)"}`,
      borderRadius: "14px",
      padding: "1.25rem",
      marginBottom: "1.5rem",
    }} className={`fade-in ${glowClass}`}>
      <div style={{ display: "flex", alignItems: "center", gap: "0.65rem", marginBottom: "1rem" }}>
        {coin === "BTC" ? <BitcoinIcon size={24} /> : <EthereumIcon size={24} />}
        <span style={{ fontWeight: 700, fontSize: "1rem", color: coinColor }} className={textGlow}>
          Ringkasan {coin}
        </span>
        <span style={{
          marginLeft: "auto",
          background: coin === "BTC" ? "var(--btc-dim)" : "var(--eth-dim)",
          border: `1px solid ${coin === "BTC" ? "rgba(247,147,26,0.3)" : "rgba(98,126,234,0.3)"}`,
          borderRadius: "20px",
          padding: "0.2rem 0.75rem",
          fontSize: "0.78rem",
          fontWeight: 600,
          color: coinColor,
        }}>{filtered.length} transaksi</span>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "0.75rem" }}>
        {[
          { label: `Total ${coin}`, value: formatCoin(totalKoin, coin), highlight: true },
          { label: "DCA Rata-rata", value: formatRp(dcaRata) },
          { label: "Total Modal Bersih", value: formatRp(totalModalBersih) },
          { label: "Total Fee", value: formatRp(totalFee), danger: true },
        ].map(item => (
          <div key={item.label} style={{
            background: "var(--bg-2)",
            borderRadius: "10px",
            padding: "0.75rem 0.9rem",
          }}>
            <div style={{ fontSize: "0.72rem", color: "var(--text-muted)", marginBottom: "0.3rem", textTransform: "uppercase", letterSpacing: "0.04em" }}>
              {item.label}
            </div>
            <div style={{
              fontFamily: "'JetBrains Mono', monospace",
              fontSize: "0.92rem",
              fontWeight: 700,
              color: item.highlight ? coinColor : item.danger ? "#FF6B6B" : "var(--text)",
            }}>
              {item.value}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function RefreshIcon({ size = 16, spinning = false }: { size?: number; spinning?: boolean }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
      strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
      style={{ animation: spinning ? "spin 1s linear infinite" : "none" }}>
      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
      <polyline points="23 4 23 10 17 10" />
      <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10" />
    </svg>
  );
}

function IndodaxLogo({ size = 14 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <rect width="24" height="24" rx="4" fill="#1E3A5F" />
      <text x="12" y="17" fontSize="12" fontWeight="800" textAnchor="middle" fill="#00C4FF" fontFamily="monospace">IX</text>
    </svg>
  );
}

interface ChartPoint { time: number; price: number; label: string; }

function useChartData(pair: string) {
  const [data, setData] = useState<ChartPoint[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    fetch(`/api/chart/${pair}`, { cache: "no-store" })
      .then(r => { if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.json(); })
      .then((d: { prices: ChartPoint[] }) => { setData(d.prices); setLoading(false); })
      .catch(e => { setError(e.message); setLoading(false); });
  }, [pair]);

  return { data, loading, error };
}

function shortRp(n: number): string {
  if (n >= 1_000_000_000) return `${(n / 1_000_000_000).toFixed(2)}M`;
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}jt`;
  return `${(n / 1_000).toFixed(0)}rb`;
}

function PriceChart({ pair, color, gradientId }: { pair: string; color: string; gradientId: string }) {
  const { data, loading, error } = useChartData(pair);
  const label = pair === "btcidr" ? "BTC" : "ETH";

  const min = data.length ? Math.min(...data.map(d => d.price)) * 0.999 : 0;
  const max = data.length ? Math.max(...data.map(d => d.price)) * 1.001 : 0;

  const CustomTooltip = ({ active, payload, label: lbl }: { active?: boolean; payload?: { value: number }[]; label?: string }) => {
    if (!active || !payload?.length) return null;
    return (
      <div style={{
        background: "rgba(10,25,47,0.92)", border: `1px solid ${color}40`,
        borderRadius: "8px", padding: "0.5rem 0.75rem", fontSize: "0.78rem",
      }}>
        <div style={{ color: "var(--text-muted)", marginBottom: "2px" }}>{lbl}</div>
        <div style={{ color, fontFamily: "'JetBrains Mono', monospace", fontWeight: 700 }}>
          Rp {payload[0].value.toLocaleString("id-ID")}
        </div>
      </div>
    );
  };

  if (loading) return (
    <div style={{
      height: 110, display: "flex", alignItems: "center", justifyContent: "center",
      color: "var(--text-muted)", fontSize: "0.8rem",
    }}>
      Memuat chart {label}...
    </div>
  );

  if (error || !data.length) return (
    <div style={{
      height: 110, display: "flex", alignItems: "center", justifyContent: "center",
      color: "var(--text-muted)", fontSize: "0.78rem",
    }}>
      Data chart tidak tersedia
    </div>
  );

  return (
    <ResponsiveContainer width="100%" height={110}>
      <AreaChart data={data} margin={{ top: 6, right: 4, left: 0, bottom: 0 }}>
        <defs>
          <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.25} />
            <stop offset="100%" stopColor={color} stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
        <XAxis
          dataKey="label"
          tick={{ fontSize: 9, fill: "var(--text-muted)", fontFamily: "monospace" }}
          tickLine={false} axisLine={false}
          interval={Math.floor(data.length / 6)}
        />
        <YAxis
          domain={[min, max]}
          tickFormatter={shortRp}
          tick={{ fontSize: 9, fill: "var(--text-muted)", fontFamily: "monospace" }}
          tickLine={false} axisLine={false}
          width={42}
        />
        <Tooltip content={<CustomTooltip />} />
        <Area
          type="monotone" dataKey="price"
          stroke={color} strokeWidth={2}
          fill={`url(#${gradientId})`}
          dot={false} activeDot={{ r: 4, fill: color, strokeWidth: 0 }}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

function DashboardTab({ transactions, onImport }: { transactions: Transaction[]; onImport: (txs: Transaction[]) => void }) {
  const { btc, eth, loading, error, lastUpdated, refetch } = useIndodaxPrices();
  const importRef = useRef<HTMLInputElement>(null);
  const [importMsg, setImportMsg] = useState<{ text: string; ok: boolean } | null>(null);

  const handleExport = () => {
    const payload = JSON.stringify(transactions, null, 2);
    const blob = new Blob([payload], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `btceth-transaksi-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const parsed = JSON.parse(ev.target?.result as string);
        if (!Array.isArray(parsed)) throw new Error("Format tidak valid");
        const valid = parsed.every(
          (t) =>
            typeof t.id === "string" &&
            typeof t.date === "string" &&
            (t.coin === "BTC" || t.coin === "ETH") &&
            typeof t.jumlahBeli === "number" &&
            typeof t.fee === "number" &&
            typeof t.hargaBeliPerCoin === "number"
        );
        if (!valid) throw new Error("Data tidak sesuai format");
        onImport(parsed as Transaction[]);
        setImportMsg({ text: `✓ ${parsed.length} transaksi berhasil diimpor`, ok: true });
      } catch (err) {
        setImportMsg({ text: `✗ Gagal: ${err instanceof Error ? err.message : "File tidak valid"}`, ok: false });
      }
      setTimeout(() => setImportMsg(null), 4000);
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  const hargaBtc = btc?.last ?? 0;
  const hargaEth = eth?.last ?? 0;

  const btcTx = transactions.filter(t => t.coin === "BTC");
  const ethTx = transactions.filter(t => t.coin === "ETH");

  const totalBtc = btcTx.reduce((s, t) => {
    const mb = t.jumlahBeli - t.fee;
    return s + (t.hargaBeliPerCoin > 0 ? mb / t.hargaBeliPerCoin : 0);
  }, 0);
  const totalEth = ethTx.reduce((s, t) => {
    const mb = t.jumlahBeli - t.fee;
    return s + (t.hargaBeliPerCoin > 0 ? mb / t.hargaBeliPerCoin : 0);
  }, 0);

  const nilaiBtc = totalBtc * hargaBtc;
  const nilaiEth = totalEth * hargaEth;
  const totalAset = nilaiBtc + nilaiEth;
  const modalBersihBtc = btcTx.reduce((s, t) => s + (t.jumlahBeli - t.fee), 0);
  const modalBersihEth = ethTx.reduce((s, t) => s + (t.jumlahBeli - t.fee), 0);
  const totalModalBersih = modalBersihBtc + modalBersihEth;
  const profitBtc = nilaiBtc - modalBersihBtc;
  const profitEth = nilaiEth - modalBersihEth;
  const profit = totalAset - totalModalBersih;
  const isProfit = profit >= 0;
  const isProfitBtc = profitBtc >= 0;
  const isProfitEth = profitEth >= 0;
  const profitPct = totalModalBersih > 0 ? (profit / totalModalBersih) * 100 : 0;
  const profitBtcPct = modalBersihBtc > 0 ? (profitBtc / modalBersihBtc) * 100 : 0;
  const profitEthPct = modalBersihEth > 0 ? (profitEth / modalBersihEth) * 100 : 0;
  const hasPrices = hargaBtc > 0 && hargaEth > 0;

  const formatTime = (d: Date) =>
    d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", second: "2-digit" });

  return (
    <div className="fade-in">
      {/* 24H Chart */}
      <div style={{
        background: "var(--card)",
        border: "1px solid var(--border-strong)",
        borderRadius: "14px",
        padding: "1rem 1.25rem 0.75rem",
        marginBottom: "1.25rem",
        backdropFilter: "blur(12px)",
        WebkitBackdropFilter: "blur(12px)",
      }}>
        <div style={{ fontSize: "0.75rem", fontWeight: 600, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: "0.5rem" }}>
          📈 24 Jam Terakhir
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.75rem" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "0.35rem", marginBottom: "0.25rem" }}>
              <BitcoinIcon size={13} />
              <span style={{ fontSize: "0.68rem", color: BTC_COLOR, fontWeight: 700, letterSpacing: "0.04em" }}>BTC / IDR</span>
            </div>
            <PriceChart pair="btcidr" color={BTC_COLOR} gradientId="grad-btc" />
          </div>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "0.35rem", marginBottom: "0.25rem" }}>
              <EthereumIcon size={13} />
              <span style={{ fontSize: "0.68rem", color: ETH_COLOR, fontWeight: 700, letterSpacing: "0.04em" }}>ETH / IDR</span>
            </div>
            <PriceChart pair="ethidr" color={ETH_COLOR} gradientId="grad-eth" />
          </div>
        </div>
      </div>

      {/* Live Price Card */}
      <div style={{
        background: "var(--card)",
        border: "1px solid var(--border-strong)",
        borderRadius: "14px",
        padding: "1.1rem 1.25rem",
        marginBottom: "1.25rem",
      }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "0.9rem" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
            <IndodaxLogo size={18} />
            <span style={{ fontSize: "0.8rem", fontWeight: 600, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.05em" }}>
              Harga Live · Indodax
            </span>
            {loading && (
              <span style={{ fontSize: "0.7rem", color: "var(--accent)", display: "flex", alignItems: "center", gap: "0.3rem" }}>
                <RefreshIcon size={12} spinning /> Memperbarui...
              </span>
            )}
            {error && (
              <span style={{ fontSize: "0.7rem", color: "#FF6B6B" }}>
                ⚠ {error}
              </span>
            )}
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
            {lastUpdated && (
              <span style={{ fontSize: "0.7rem", color: "var(--text-muted)", fontFamily: "'JetBrains Mono', monospace" }}>
                {formatTime(lastUpdated)}
              </span>
            )}
            <button
              onClick={refetch}
              disabled={loading}
              title="Refresh harga"
              style={{
                background: "var(--accent-dim)", border: "1px solid var(--border-strong)",
                borderRadius: "8px", padding: "0.3rem 0.55rem", cursor: loading ? "not-allowed" : "pointer",
                color: "var(--accent)", display: "flex", alignItems: "center", opacity: loading ? 0.5 : 1,
                transition: "all 0.2s",
              }}
            >
              <RefreshIcon size={14} spinning={loading} />
            </button>
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.75rem" }}>
          {/* BTC Price */}
          <div className="card-box" style={{
            background: "var(--btc-dim)",
            border: "1px solid rgba(247,147,26,0.25)",
            borderRadius: "10px",
            padding: "0.75rem",
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: "0.4rem", marginBottom: "0.5rem" }}>
              <BitcoinIcon size={16} />
              <span style={{ fontSize: "0.72rem", color: "#F7931A", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.04em" }}>BTC / IDR</span>
            </div>
            {hargaBtc > 0 ? (
              <div className="price-row" style={{ color: BTC_COLOR }}>
                <span className="price-rp">Rp</span>
                <span className="price-num">{formatNum(hargaBtc)}</span>
              </div>
            ) : (
              <div style={{ color: "var(--text-muted)", fontSize: "0.8rem" }}>Memuat...</div>
            )}
            {btc && (
              <div style={{ display: "flex", flexWrap: "wrap", gap: "0.4rem", marginTop: "0.4rem" }}>
                <span style={{ fontSize: "0.66rem", color: "var(--profit)", whiteSpace: "nowrap" }}>▲ {formatRp(btc.buy)}</span>
                <span style={{ fontSize: "0.66rem", color: "var(--loss)", whiteSpace: "nowrap" }}>▼ {formatRp(btc.sell)}</span>
              </div>
            )}
          </div>

          {/* ETH Price */}
          <div className="card-box" style={{
            background: "var(--eth-dim)",
            border: "1px solid rgba(98,126,234,0.25)",
            borderRadius: "10px",
            padding: "0.75rem",
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: "0.4rem", marginBottom: "0.5rem" }}>
              <EthereumIcon size={16} />
              <span style={{ fontSize: "0.72rem", color: ETH_COLOR, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.04em" }}>ETH / IDR</span>
            </div>
            {hargaEth > 0 ? (
              <div className="price-row" style={{ color: ETH_COLOR }}>
                <span className="price-rp">Rp</span>
                <span className="price-num">{formatNum(hargaEth)}</span>
              </div>
            ) : (
              <div style={{ color: "var(--text-muted)", fontSize: "0.8rem" }}>Memuat...</div>
            )}
            {eth && (
              <div style={{ display: "flex", flexWrap: "wrap", gap: "0.4rem", marginTop: "0.4rem" }}>
                <span style={{ fontSize: "0.66rem", color: "var(--profit)", whiteSpace: "nowrap" }}>▲ {formatRp(eth.buy)}</span>
                <span style={{ fontSize: "0.66rem", color: "var(--loss)", whiteSpace: "nowrap" }}>▼ {formatRp(eth.sell)}</span>
              </div>
            )}
          </div>
        </div>
        <div style={{ marginTop: "0.6rem", fontSize: "0.68rem", color: "var(--text-muted)", textAlign: "right" }}>
          Auto-refresh setiap 30 detik
        </div>
      </div>

      {/* Asset Cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "0.85rem", marginBottom: "1.25rem" }}>
        {[
          { label: "Total Bitcoin", value: formatCoin(totalBtc, "BTC"), color: BTC_COLOR, icon: <BitcoinIcon size={18} />, sub: hargaBtc > 0 ? `@ ${formatRp(hargaBtc)}` : "—" },
          { label: "Total Ethereum", value: formatCoin(totalEth, "ETH"), color: ETH_COLOR, icon: <EthereumIcon size={18} />, sub: hargaEth > 0 ? `@ ${formatRp(hargaEth)}` : "—" },
          { label: "Nilai BTC (Rp)", value: hasPrices ? formatRp(nilaiBtc) : "—", color: BTC_COLOR, icon: <BitcoinIcon size={18} /> },
          { label: "Nilai ETH (Rp)", value: hasPrices ? formatRp(nilaiEth) : "—", color: ETH_COLOR, icon: <EthereumIcon size={18} /> },
          { label: "Total Aset", value: hasPrices ? formatRp(totalAset) : "—", color: ACCENT, special: true },
          { label: "Total Modal Bersih", value: formatRp(totalModalBersih), color: "var(--text)" },
        ].map(card => (
          <div key={card.label} className="card-box card-pad" style={{
            background: "var(--card)",
            border: (card as {special?: boolean}).special ? "1px solid var(--border-strong)" : "1px solid var(--border)",
            borderRadius: "12px",
            boxShadow: (card as {special?: boolean}).special ? "var(--accent-glow)" : "none",
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: "0.4rem", marginBottom: "0.5rem" }}>
              {(card as {icon?: React.ReactNode}).icon && <span>{(card as {icon?: React.ReactNode}).icon}</span>}
              <span style={{ fontSize: "0.72rem", color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.04em" }}>{card.label}</span>
            </div>
            <div className="card-val" style={{ color: card.color }}>
              {card.value}
            </div>
            {(card as {sub?: string}).sub && (
              <div style={{ fontSize: "0.7rem", color: "var(--text-muted)", marginTop: "0.25rem" }}>
                {(card as {sub?: string}).sub}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Profit BTC & ETH Breakdown */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.85rem", marginBottom: "1.25rem" }}>
        {/* Profit BTC */}
        <div className="card-box card-pad" style={{
          background: !hasPrices || btcTx.length === 0 ? "var(--card)" : isProfitBtc ? "rgba(100,255,218,0.06)" : "rgba(255,107,107,0.06)",
          border: `1px solid ${!hasPrices || btcTx.length === 0 ? "rgba(247,147,26,0.2)" : isProfitBtc ? "rgba(100,255,218,0.25)" : "rgba(255,107,107,0.25)"}`,
          borderRadius: "12px",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: "0.4rem", marginBottom: "0.6rem" }}>
            <BitcoinIcon size={16} />
            <span style={{ fontSize: "0.72rem", color: BTC_COLOR, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.04em" }}>
              Profit BTC
            </span>
          </div>
          <div className="card-val" style={{
            fontWeight: 800,
            color: !hasPrices || btcTx.length === 0 ? "var(--text-muted)" : isProfitBtc ? "var(--profit)" : "var(--loss)",
          }}>
            {!hasPrices ? "Memuat..." : btcTx.length === 0 ? "—" : `${isProfitBtc ? "+" : ""}${formatRp(profitBtc)}`}
          </div>
          {hasPrices && btcTx.length > 0 && (
            <div style={{
              display: "inline-flex", alignItems: "center", gap: "0.25rem",
              marginTop: "0.4rem",
              background: isProfitBtc ? "rgba(100,255,218,0.1)" : "rgba(255,107,107,0.1)",
              borderRadius: "20px", padding: "0.2rem 0.6rem",
              color: isProfitBtc ? "var(--profit)" : "var(--loss)",
              fontSize: "0.75rem", fontWeight: 700, fontFamily: "'JetBrains Mono', monospace",
            }}>
              {isProfitBtc ? <TrendUpIcon size={12} /> : <TrendDownIcon size={12} />}
              {isProfitBtc ? "+" : ""}{profitBtcPct.toFixed(2)}%
            </div>
          )}
        </div>

        {/* Profit ETH */}
        <div className="card-box card-pad" style={{
          background: !hasPrices || ethTx.length === 0 ? "var(--card)" : isProfitEth ? "rgba(100,255,218,0.06)" : "rgba(255,107,107,0.06)",
          border: `1px solid ${!hasPrices || ethTx.length === 0 ? "rgba(98,126,234,0.2)" : isProfitEth ? "rgba(100,255,218,0.25)" : "rgba(255,107,107,0.25)"}`,
          borderRadius: "12px",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: "0.4rem", marginBottom: "0.6rem" }}>
            <EthereumIcon size={16} />
            <span style={{ fontSize: "0.72rem", color: ETH_COLOR, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.04em" }}>
              Profit ETH
            </span>
          </div>
          <div className="card-val" style={{
            fontWeight: 800,
            color: !hasPrices || ethTx.length === 0 ? "var(--text-muted)" : isProfitEth ? "var(--profit)" : "var(--loss)",
          }}>
            {!hasPrices ? "Memuat..." : ethTx.length === 0 ? "—" : `${isProfitEth ? "+" : ""}${formatRp(profitEth)}`}
          </div>
          {hasPrices && ethTx.length > 0 && (
            <div style={{
              display: "inline-flex", alignItems: "center", gap: "0.25rem",
              marginTop: "0.4rem",
              background: isProfitEth ? "rgba(100,255,218,0.1)" : "rgba(255,107,107,0.1)",
              borderRadius: "20px", padding: "0.2rem 0.6rem",
              color: isProfitEth ? "var(--profit)" : "var(--loss)",
              fontSize: "0.75rem", fontWeight: 700, fontFamily: "'JetBrains Mono', monospace",
            }}>
              {isProfitEth ? <TrendUpIcon size={12} /> : <TrendDownIcon size={12} />}
              {isProfitEth ? "+" : ""}{profitEthPct.toFixed(2)}%
            </div>
          )}
        </div>
      </div>

      {/* Profit / Loss */}
      <div style={{
        background: !hasPrices ? "var(--card)" : isProfit ? "rgba(100,255,218,0.07)" : "rgba(255,107,107,0.07)",
        border: `1px solid ${!hasPrices ? "var(--border)" : isProfit ? "rgba(100,255,218,0.3)" : "rgba(255,107,107,0.3)"}`,
        borderRadius: "14px",
        padding: "1.25rem 1.5rem",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        flexWrap: "wrap",
        gap: "0.75rem",
        boxShadow: !hasPrices ? "none" : isProfit ? "0 0 20px rgba(100,255,218,0.12)" : "0 0 20px rgba(255,107,107,0.08)",
      }}>
        <div>
          <div style={{ fontSize: "0.78rem", color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: "0.35rem" }}>
            {!hasPrices ? "Profit / Loss" : isProfit ? "🚀 Total Profit" : "📉 Total Loss"}
          </div>
          <div className="card-val-profit" style={{
            color: !hasPrices ? "var(--text-muted)" : isProfit ? "var(--profit)" : "var(--loss)",
            textShadow: !hasPrices ? "none" : isProfit ? "0 0 20px rgba(100,255,218,0.5)" : "0 0 20px rgba(255,107,107,0.5)",
          }}>
            {!hasPrices ? "Menunggu harga..." : `${isProfit ? "+" : ""}${formatRp(profit)}`}
          </div>
        </div>
        {hasPrices && (
          <div style={{
            display: "flex",
            alignItems: "center",
            gap: "0.4rem",
            background: isProfit ? "rgba(100,255,218,0.12)" : "rgba(255,107,107,0.12)",
            borderRadius: "30px",
            padding: "0.5rem 1rem",
            color: isProfit ? "var(--profit)" : "var(--loss)",
            fontWeight: 700,
            fontSize: "1rem",
            fontFamily: "'JetBrains Mono', monospace",
          }}>
            {isProfit ? <TrendUpIcon size={18} /> : <TrendDownIcon size={18} />}
            {isProfit ? "+" : ""}{profitPct.toFixed(2)}%
          </div>
        )}
      </div>

      {transactions.length === 0 && (
        <div style={{
          marginTop: "1.5rem",
          textAlign: "center",
          color: "var(--text-muted)",
          fontSize: "0.88rem",
          padding: "2rem",
          background: "var(--card)",
          borderRadius: "12px",
          border: "1px dashed var(--border-strong)",
        }}>
          Belum ada transaksi. Tambahkan transaksi di tab BTC atau ETH.
        </div>
      )}

      {/* Export / Import */}
      <div style={{ marginTop: "1.5rem", display: "flex", gap: "0.75rem" }}>
        <button
          onClick={handleExport}
          disabled={transactions.length === 0}
          style={{
            flex: 1,
            display: "flex", alignItems: "center", justifyContent: "center", gap: "0.5rem",
            padding: "0.75rem 1rem",
            background: transactions.length === 0 ? "var(--bg-2)" : "var(--accent-dim)",
            border: "1px solid var(--border-strong)",
            borderRadius: "10px",
            color: transactions.length === 0 ? "var(--text-muted)" : "var(--accent)",
            fontFamily: "'Space Grotesk', sans-serif",
            fontWeight: 600, fontSize: "0.88rem",
            cursor: transactions.length === 0 ? "not-allowed" : "pointer",
            transition: "all 0.2s",
          }}
          onMouseEnter={e => {
            if (transactions.length > 0) {
              (e.currentTarget as HTMLButtonElement).style.boxShadow = "var(--accent-glow)";
              (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--accent)";
            }
          }}
          onMouseLeave={e => {
            (e.currentTarget as HTMLButtonElement).style.boxShadow = "none";
            (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--border-strong)";
          }}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
            <polyline points="7 10 12 15 17 10"/>
            <line x1="12" y1="15" x2="12" y2="3"/>
          </svg>
          Export Data
          {transactions.length > 0 && (
            <span style={{
              background: "rgba(100,255,218,0.15)", borderRadius: "20px",
              padding: "0.1rem 0.5rem", fontSize: "0.75rem", fontWeight: 700,
            }}>
              {transactions.length}
            </span>
          )}
        </button>

        <button
          onClick={() => importRef.current?.click()}
          style={{
            flex: 1,
            display: "flex", alignItems: "center", justifyContent: "center", gap: "0.5rem",
            padding: "0.75rem 1rem",
            background: "var(--bg-2)",
            border: "1px solid var(--border-strong)",
            borderRadius: "10px",
            color: "var(--text)",
            fontFamily: "'Space Grotesk', sans-serif",
            fontWeight: 600, fontSize: "0.88rem",
            cursor: "pointer",
            transition: "all 0.2s",
          }}
          onMouseEnter={e => {
            (e.currentTarget as HTMLButtonElement).style.borderColor = "rgba(255,255,255,0.3)";
            (e.currentTarget as HTMLButtonElement).style.background = "var(--card)";
          }}
          onMouseLeave={e => {
            (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--border-strong)";
            (e.currentTarget as HTMLButtonElement).style.background = "var(--bg-2)";
          }}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
            <polyline points="17 8 12 3 7 8"/>
            <line x1="12" y1="3" x2="12" y2="15"/>
          </svg>
          Import Data
        </button>

        <input
          ref={importRef}
          type="file"
          accept=".json,application/json"
          onChange={handleImportFile}
          style={{ display: "none" }}
        />
      </div>

      {importMsg && (
        <div className="fade-in" style={{
          marginTop: "0.75rem",
          padding: "0.65rem 1rem",
          borderRadius: "8px",
          fontSize: "0.85rem",
          fontWeight: 500,
          background: importMsg.ok ? "rgba(100,255,218,0.08)" : "rgba(255,107,107,0.08)",
          border: `1px solid ${importMsg.ok ? "rgba(100,255,218,0.3)" : "rgba(255,107,107,0.3)"}`,
          color: importMsg.ok ? "var(--profit)" : "var(--loss)",
        }}>
          {importMsg.text}
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>("BTC");
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(transactions));
  }, [transactions]);

  const addTransaction = useCallback((tx: Transaction) => {
    setTransactions(prev => [tx, ...prev]);
  }, []);

  const deleteTransaction = useCallback((id: string) => {
    setTransactions(prev => prev.filter(t => t.id !== id));
  }, []);

  return (
    <div style={{
      minHeight: "100dvh",
      background: "var(--bg)",
      backgroundImage: "radial-gradient(ellipse at 20% 0%, rgba(100,255,218,0.04) 0%, transparent 60%), radial-gradient(ellipse at 80% 100%, rgba(98,126,234,0.04) 0%, transparent 60%)",
      paddingBottom: "2rem",
    }}>
      <header style={{
        borderBottom: "1px solid var(--border)",
        background: "rgba(10,25,47,0.85)",
        backdropFilter: "blur(12px)",
        WebkitBackdropFilter: "blur(12px)",
        position: "sticky",
        top: 0,
        zIndex: 100,
      }}>
        <div style={{ maxWidth: "900px", margin: "0 auto", padding: "0 1rem" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", paddingTop: "1rem", paddingBottom: "0.5rem" }}>
            <div style={{
              width: "36px", height: "36px", borderRadius: "10px",
              background: "var(--accent-dim)",
              border: "1px solid var(--border-strong)",
              display: "flex", alignItems: "center", justifyContent: "center",
              boxShadow: "var(--accent-glow)",
            }}>
              <CodeIcon size={18} />
            </div>
            <div>
              <h1 style={{ fontSize: "1.1rem", fontWeight: 700, color: "var(--text)", lineHeight: 1.2 }}>
                BTC <span style={{ color: "var(--text-muted)", fontWeight: 400 }}>&</span> ETH
              </h1>
              <p style={{ fontSize: "0.72rem", color: "var(--text-muted)", letterSpacing: "0.08em", textTransform: "uppercase" }}>
                Investment Tracker
              </p>
            </div>
            <div style={{ marginLeft: "auto", display: "flex", gap: "0.4rem" }}>
              <div style={{
                background: "var(--btc-dim)",
                border: "1px solid rgba(247,147,26,0.3)",
                borderRadius: "20px", padding: "0.2rem 0.6rem",
                fontSize: "0.72rem", fontWeight: 700, color: BTC_COLOR,
              }}>₿ BTC</div>
              <div style={{
                background: "var(--eth-dim)",
                border: "1px solid rgba(98,126,234,0.3)",
                borderRadius: "20px", padding: "0.2rem 0.6rem",
                fontSize: "0.72rem", fontWeight: 700, color: ETH_COLOR,
              }}>Ξ ETH</div>
            </div>
          </div>
          <nav style={{ display: "flex", gap: 0 }}>
            {tabs.map(tab => {
              const isActive = activeTab === tab;
              const tabColor = tab === "BTC" ? BTC_COLOR : tab === "ETH" ? ETH_COLOR : ACCENT;
              return (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  style={{
                    padding: "0.6rem 1.25rem",
                    background: "none",
                    border: "none",
                    borderBottom: isActive ? `2px solid ${tabColor}` : "2px solid transparent",
                    color: isActive ? tabColor : "var(--text-muted)",
                    fontFamily: "'Space Grotesk', sans-serif",
                    fontWeight: isActive ? 700 : 500,
                    fontSize: "0.88rem",
                    cursor: "pointer",
                    transition: "all 0.2s",
                    display: "flex",
                    alignItems: "center",
                    gap: "0.4rem",
                    textShadow: isActive && tab !== "Dashboard" ? (tab === "BTC" ? "0 0 10px rgba(247,147,26,0.4)" : "0 0 10px rgba(98,126,234,0.4)") : "none",
                  }}
                >
                  {tab === "BTC" && <BitcoinIcon size={14} />}
                  {tab === "ETH" && <EthereumIcon size={14} />}
                  {tab === "Dashboard" && <TrendUpIcon size={14} />}
                  {tab}
                </button>
              );
            })}
          </nav>
        </div>
      </header>

      <main style={{ maxWidth: "900px", margin: "0 auto", padding: "1.5rem 1rem 0" }}>
        {(activeTab === "BTC" || activeTab === "ETH") && (
          <div className="fade-in">
            <CoinSummaryCard coin={activeTab} transactions={transactions} />
            <TransactionForm onAdd={addTransaction} defaultCoin={activeTab} />
            <div style={{ marginTop: "0.5rem" }}>
              <h2 style={{ fontSize: "0.82rem", fontWeight: 600, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: "0.75rem" }}>
                Riwayat Transaksi {activeTab}
              </h2>
              <TransactionTable transactions={transactions} coin={activeTab} onDelete={deleteTransaction} />
            </div>
          </div>
        )}
        {activeTab === "Dashboard" && (
          <DashboardTab transactions={transactions} onImport={setTransactions} />
        )}
      </main>
    </div>
  );
}
