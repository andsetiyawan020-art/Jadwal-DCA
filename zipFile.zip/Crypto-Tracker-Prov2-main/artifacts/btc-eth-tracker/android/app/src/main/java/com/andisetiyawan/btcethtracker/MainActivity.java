package com.andisetiyawan.btcethtracker;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
